#!/usr/bin/env python3
"""
Carvalho Antifer geometry - dimensioned PDF and ZWCAD-compatible DXF
================================================================

Production drawing generator for the Carvalho Antifer armour-unit geometry. The
script writes two deterministic deliverables in the selected output directory:

    antifer_carvalho_geometry.pdf
    antifer_carvalho_geometry.dxf

The drawings are non-dimensional and use H as the reference length. They are
intended for engineering documentation, geometric checking and CAD review. The
script is not a hydraulic stability calculator and does not size armour units
from wave climate, damage criteria or placement method.

Geometric convention
--------------------
The adopted Carvalho geometry is the volume-normalised Antifer profile defined by the following ratios:

    A/H = 1.072831     bottom bounding width at z = 0
    B/H = 0.992814     top bounding width at z = H
    C/H = 0.094434     generated circular-arc groove inset
    D/H = 0.023709     lateral corner-chamfer offset in plan
    R/H = 0.120027     circular-groove radius

The top face is a single horizontal plane at z = H. There is no top bevel and
no intermediate H-D level. The four corner chamfers are lateral plan chamfers.
Each side groove is reconstructed as one continuous circular arc of absolute
radius R, without an auxiliary straight inner segment.

Volume convention
-----------------
The Carvalho normalised volume coefficient is:

    CARVALHO_KV = 1.000000000000

This coefficient fixes the one-groove circular-segment area for V/H^3 = 1. The script solves
for the outside groove-centre offset E/H, then reports the derived groove depth,
half-opening and algebraic volume balance.

CAD/PDF conventions
-------------------
The DXF writer uses conservative ASCII text for formulae so that exponents and
mathematical symbols remain legible in ZWCAD/AutoCAD-compatible viewers using
legacy SHX-style fonts. PDF output requests a single-column continuous page
layout when the optional pypdf package is available.

Typical use
-----------
    python antifer_carvalho_geometry.py
    python antifer_carvalho_geometry.py --out-dir output_folder
    python antifer_carvalho_geometry.py --pdf drawing.pdf --dxf drawing.dxf

Required dependency: matplotlib. Optional dependency for PDF page-layout metadata:
pypdf.
"""

from __future__ import annotations

import argparse
import math
import textwrap
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import FancyArrowPatch, Polygon

# Type aliases keep geometry signatures readable while remaining compatible
# with Python 3.10+ built-in generic annotations.
Point2D = tuple[float, float]
Polyline2D = list[Point2D]
SegmentList2D = list[Polyline2D]

# =============================================================================
# NON-DIMENSIONAL GEOMETRY AND DRAWING CONSTANTS
# =============================================================================

# Carvalho normalised volume coefficient used as the algebraic volume target.
CARVALHO_KV = 1.000000000000

# Carvalho non-dimensional geometry. All generated drawing coordinates are scaled
# from these ratios using H = 1.0 as the plotting reference. The coefficients
# are obtained from the active Pita profile using f = sqrt(1/1.0247), so the
# generated closed CAD/B-rep volume coefficient is exactly V/H^3 = 1.
A_OVER_H = 1.072831353161138
B_OVER_H = 0.992813545052434
C_OVER_H = 0.094434389769995
D_OVER_H = 0.023708980180357
R_OVER_H = 0.120026712163056

# Production discretisation of each circular groove arc. This value controls
# the visual smoothness of the plan/DXF curve and is intentionally fixed.
ARC_POINTS = 144

# ISO A4 landscape size in inches for Matplotlib/PdfPages.
PDF_SIZE_A4_LANDSCAPE = (11.69, 8.27)


@dataclass(frozen=True)
class AntiferGeometry:
    """Immutable non-dimensional definition of the Carvalho Antifer geometry.

    The dataclass stores only the independent Carvalho coefficients. Derived
    quantities such as groove centre offset, groove half-opening, circular
    segment area and volume coefficient are exposed as properties so every PDF
    and DXF annotation is calculated from the same source of truth.
    """

    a: float = A_OVER_H
    b: float = B_OVER_H
    c: float = C_OVER_H
    d: float = D_OVER_H
    r: float = R_OVER_H
    carvalho_kv: float = CARVALHO_KV

    @property
    def side_batter_per_side(self) -> float:
        return 0.5 * (self.a - self.b)

    @property
    def gross_square_frustum_coefficient(self) -> float:
        return (self.a**2 + self.a * self.b + self.b**2) / 3.0

    @property
    def removed_corner_volume_coefficient(self) -> float:
        return 2.0 * self.d**2

    @property
    def target_one_groove_area(self) -> float:
        return (
            self.gross_square_frustum_coefficient
            - self.removed_corner_volume_coefficient
            - self.carvalho_kv
        ) / 4.0

    @staticmethod
    def circular_segment_area_from_offset(radius: float, offset: float) -> float:
        """Area cut by a line located offset from the circle centre.

        The offset is the distance from the circle centre to the side face,
        measured outward from the block. The removed groove area is the circular
        segment inside the block.
        """
        if offset < -1.0e-14 or offset > radius + 1.0e-14:
            raise ValueError("Circle-centre offset must lie within [0, radius].")
        offset = min(max(offset, 0.0), radius)
        return radius**2 * math.acos(offset / radius) - offset * math.sqrt(
            max(0.0, radius**2 - offset**2)
        )

    @property
    def groove_centre_offset_outside_face(self) -> float:
        """Outside offset of the circular-arc centre.

        The offset is determined by the adopted Carvalho volume coefficient.
        """
        target = self.target_one_groove_area
        half_circle_area = 0.5 * math.pi * self.r**2
        if not 0.0 < target < half_circle_area:
            raise ValueError(
                "The target groove area must be between zero and the half-circle area."
            )

        lo = 0.0
        hi = self.r
        for _ in range(90):
            mid = 0.5 * (lo + hi)
            area = self.circular_segment_area_from_offset(self.r, mid)
            if area > target:
                lo = mid
            else:
                hi = mid
        return 0.5 * (lo + hi)

    @property
    def groove_depth(self) -> float:
        """Maximum groove inset generated by the circular arc."""
        return self.r - self.groove_centre_offset_outside_face

    @property
    def groove_half_opening(self) -> float:
        offset = self.groove_centre_offset_outside_face
        return math.sqrt(max(0.0, self.r**2 - offset**2))

    @property
    def groove_opening(self) -> float:
        return 2.0 * self.groove_half_opening

    @property
    def one_groove_area(self) -> float:
        return self.circular_segment_area_from_offset(
            self.r, self.groove_centre_offset_outside_face
        )

    @property
    def removed_groove_volume_coefficient(self) -> float:
        return 4.0 * self.one_groove_area

    @property
    def exact_volume_coefficient(self) -> float:
        return (
            self.gross_square_frustum_coefficient
            - self.removed_corner_volume_coefficient
            - self.removed_groove_volume_coefficient
        )

    @property
    def residual_to_carvalho(self) -> float:
        return self.exact_volume_coefficient - self.carvalho_kv


# =============================================================================
# SHARED GEOMETRY
# =============================================================================


def east_side_local_points(geom: AntiferGeometry, n: int = ARC_POINTS) -> Polyline2D:
    """Return local inward-positive points for one symmetric grooved side.

    Local convention:
        x = 0 is the side face, x > 0 is inward, y is along the side.

    The path is ordered from the lower side opening to the upper side opening.
    The groove is one continuous circular arc of radius r. No straight inner
    segment is introduced.
    """
    offset = geom.groove_centre_offset_outside_face
    q = geom.groove_half_opening
    points: Polyline2D = []
    for i in range(n):
        y = -q + 2.0 * q * i / (n - 1)
        x = -offset + math.sqrt(max(0.0, geom.r**2 - y**2))
        points.append((x, y))
    return points


def east_side_global_points(width: float, geom: AntiferGeometry) -> Polyline2D:
    h = 0.5 * width
    return [(h - x, y) for x, y in east_side_local_points(geom)]


def section_segments(width: float, geom: AntiferGeometry) -> list[Polyline2D]:
    """Return visible plan segments.

    The plan perimeter is deliberately split into separate visible entities so
    that straight side lines are interrupted at the corner chamfers and at the
    grooves. This is used by both the PDF and the DXF writers.
    """
    h = 0.5 * width
    d = geom.d
    q = geom.groove_half_opening
    if q >= h - d:
        raise ValueError("Groove opening is too large for the side length.")

    east = east_side_global_points(width, geom)  # from south to north
    north = [(-y, x) for x, y in east]  # from east to west
    west = [(-x, -y) for x, y in east]  # from north to south
    south = [(y, -x) for x, y in east]  # from west to east

    return [
        [(h - d, -h), (h, -h + d)],
        [(h, -h + d), (h, -q)],
        east,
        [(h, q), (h, h - d)],
        [(h, h - d), (h - d, h)],
        [(h - d, h), (q, h)],
        north,
        [(-q, h), (-h + d, h)],
        [(-h + d, h), (-h, h - d)],
        [(-h, h - d), (-h, q)],
        west,
        [(-h, -q), (-h, -h + d)],
        [(-h, -h + d), (-h + d, -h)],
        [(-h + d, -h), (-q, -h)],
        south,
        [(q, -h), (h - d, -h)],
    ]


def section_points(width: float, geom: AntiferGeometry) -> Polyline2D:
    """Flattened closed horizontal section, retained for compatibility."""
    points: Polyline2D = []
    for segment in section_segments(width, geom):
        for x, y in segment:
            if not points or abs(points[-1][0] - x) > 1e-12 or abs(points[-1][1] - y) > 1e-12:
                points.append((x, y))
    if points and (abs(points[0][0] - points[-1][0]) > 1e-12 or abs(points[0][1] - points[-1][1]) > 1e-12):
        points.append(points[0])
    return points


# =============================================================================
# PDF DRAWING HELPERS
# =============================================================================


def make_page(title: str) -> tuple[plt.Figure, plt.Axes]:
    """Create one landscape A4 drawing page with engineering-style axes."""
    fig, ax = plt.subplots(figsize=PDF_SIZE_A4_LANDSCAPE)
    fig.subplots_adjust(left=0.045, right=0.965, bottom=0.055, top=0.90)
    ax.set_title(title, fontsize=18, weight="bold", pad=14)
    ax.set_aspect("equal", adjustable="box")
    ax.axis("off")
    return fig, ax


def add_dim_arrow(
    ax: plt.Axes,
    xy1: Point2D,
    xy2: Point2D,
    label: str,
    label_xy: Point2D | None = None,
    rotation: float = 0.0,
    fontsize: float = 11.2,
) -> None:
    """Draw a bidirectional dimension arrow with a white-backed label."""
    ax.add_patch(
        FancyArrowPatch(
            xy1,
            xy2,
            arrowstyle="<->",
            mutation_scale=11,
            linewidth=0.85,
            color="black",
            shrinkA=0,
            shrinkB=0,
        )
    )
    if label_xy is None:
        label_xy = ((xy1[0] + xy2[0]) / 2.0, (xy1[1] + xy2[1]) / 2.0)
    ax.text(
        label_xy[0],
        label_xy[1],
        label,
        ha="center",
        va="center",
        rotation=rotation,
        fontsize=fontsize,
        bbox={"boxstyle": "round,pad=0.16", "fc": "white", "ec": "none", "alpha": 0.92},
    )


def add_tick_dim_h(
    ax: plt.Axes,
    x1: float,
    x2: float,
    y: float,
    label: str,
    label_xy: Point2D,
    fontsize: float = 10.8,
) -> None:
    """Draw a compact horizontal dimension with end ticks instead of arrows."""
    ax.plot([x1, x2], [y, y], color="black", linewidth=0.85)
    tick = 0.010
    ax.plot([x1, x1], [y - tick, y + tick], color="black", linewidth=0.85)
    ax.plot([x2, x2], [y - tick, y + tick], color="black", linewidth=0.85)
    ax.text(
        label_xy[0],
        label_xy[1],
        label,
        ha="center",
        va="center",
        fontsize=fontsize,
        bbox={"boxstyle": "round,pad=0.16", "fc": "white", "ec": "none", "alpha": 0.92},
    )


def add_tick_dim_v(
    ax: plt.Axes,
    x: float,
    y1: float,
    y2: float,
    label: str,
    label_xy: Point2D,
    fontsize: float = 10.8,
) -> None:
    """Draw a compact vertical dimension with end ticks instead of arrows."""
    ax.plot([x, x], [y1, y2], color="black", linewidth=0.85)
    tick = 0.010
    ax.plot([x - tick, x + tick], [y1, y1], color="black", linewidth=0.85)
    ax.plot([x - tick, x + tick], [y2, y2], color="black", linewidth=0.85)
    ax.text(
        label_xy[0],
        label_xy[1],
        label,
        ha="center",
        va="center",
        rotation=90.0,
        fontsize=fontsize,
        bbox={"boxstyle": "round,pad=0.16", "fc": "white", "ec": "none", "alpha": 0.92},
    )


def add_note(ax: plt.Axes, x: float, y: float, text: str, fontsize: float = 11.0, width: int = 42) -> None:
    """Place a wrapped explanatory note in a boxed text area."""
    wrapped = "\n".join(textwrap.fill(line, width=width) for line in text.split("\n"))
    ax.text(
        x,
        y,
        wrapped,
        ha="left",
        va="top",
        fontsize=fontsize,
        linespacing=1.18,
        bbox={"boxstyle": "round,pad=0.34", "fc": "white", "ec": "0.45", "lw": 0.8},
    )


def add_page_footer(fig: plt.Figure, page: int, total: int) -> None:
    """Add a consistent footer to every generated PDF page."""
    fig.text(0.50, 0.025, f"Carvalho Antifer geometry - page {page} of {total}", ha="center", va="bottom", fontsize=10.5)


def plot_section(ax: plt.Axes, width: float, geom: AntiferGeometry, lw: float = 1.7) -> None:
    """Draw a horizontal Antifer section using interrupted visible segments."""
    for segment in section_segments(width, geom):
        x, y = zip(*segment)
        ax.plot(x, y, color="black", linewidth=lw, solid_capstyle="butt")


# =============================================================================
# PDF PAGES
# =============================================================================


def pdf_front_view(pdf: PdfPages, geom: AntiferGeometry) -> None:
    """Write the elevation page showing height, top width and bottom width."""
    fig, ax = make_page("Carvalho Antifer geometry - front view")
    a2 = 0.5 * geom.a
    b2 = 0.5 * geom.b
    outline = [(-a2, 0.0), (a2, 0.0), (b2, 1.0), (-b2, 1.0)]
    ax.add_patch(Polygon(outline, closed=True, fill=False, linewidth=1.9, color="black"))
    ax.plot([-(a2 - geom.d), -(b2 - geom.d)], [0.0, 1.0], linestyle="--", linewidth=1.0, color="black")
    ax.plot([(a2 - geom.d), (b2 - geom.d)], [0.0, 1.0], linestyle="--", linewidth=1.0, color="black")

    y_base = -0.11
    y_top = 1.10
    for x, y_target in [(-a2, y_base), (a2, y_base), (-b2, y_top), (b2, y_top)]:
        y0 = 0.0 if abs(x) == a2 else 1.0
        ax.plot([x, x], [y0, y_target], color="black", linewidth=0.65)
    add_dim_arrow(ax, (-a2, y_base), (a2, y_base), f"A = {geom.a:.6f} H", (0.0, y_base - 0.035))
    add_dim_arrow(ax, (-b2, y_top), (b2, y_top), f"B = {geom.b:.6f} H", (0.0, y_top + 0.035))

    x_h = 0.70
    ax.plot([a2, x_h + 0.06], [0.0, 0.0], color="black", linewidth=0.65)
    ax.plot([b2, x_h + 0.06], [1.0, 1.0], color="black", linewidth=0.65)
    add_dim_arrow(ax, (x_h, 0.0), (x_h, 1.0), "H", (x_h + 0.05, 0.50), rotation=90.0)

    add_note(
        ax,
        -0.91,
        0.43,
        "Elevation definition\nThe upper face is a single horizontal plane at z = H. There is no top bevel. The dashed lines indicate the inward lateral corner-chamfer edges; they are slightly inclined because A is larger than B.",
        width=40,
    )
    add_note(
        ax,
        0.32,
        0.80,
        "Key derived values\n"
        f"(A-B)/2H = {geom.side_batter_per_side:.6f}\n"
        f"C/H = {geom.c:.6f}\n"
        f"q/H = {geom.groove_half_opening:.6f}",
        width=40,
    )

    ax.set_xlim(-1.00, 1.13)
    ax.set_ylim(-0.20, 1.22)
    add_page_footer(fig, 1, 5)
    pdf.savefig(fig)
    plt.close(fig)


def pdf_plan_view(pdf: PdfPages, geom: AntiferGeometry, *, top: bool) -> None:
    """Write either the top or bottom plan page."""
    title = "Carvalho Antifer geometry - top plan" if top else "Carvalho Antifer geometry - bottom plan"
    fig, ax = make_page(title)
    fig.subplots_adjust(left=0.035, right=0.975, bottom=0.045, top=0.905)
    width = geom.b if top else geom.a
    symbol = "B" if top else "A"
    h = 0.5 * width
    plot_section(ax, width, geom, lw=1.9)

    ax.plot([-0.72, 0.72], [0.0, 0.0], color="0.70", linewidth=0.7, linestyle="-.")
    ax.plot([0.0, 0.0], [-0.72, 0.72], color="0.70", linewidth=0.7, linestyle="-.")

    y_dim = -h - 0.12
    x_dim = h + 0.13
    ax.plot([-h, -h], [-h, y_dim], color="black", linewidth=0.65)
    ax.plot([h, h], [-h, y_dim], color="black", linewidth=0.65)
    ax.plot([h, x_dim], [-h, -h], color="black", linewidth=0.65)
    ax.plot([h, x_dim], [h, h], color="black", linewidth=0.65)
    add_dim_arrow(ax, (-h, y_dim), (h, y_dim), f"{symbol} = {width:.6f} H", (0.0, y_dim - 0.040))
    add_dim_arrow(ax, (x_dim, -h), (x_dim, h), f"{symbol} = {width:.6f} H", (x_dim + 0.045, 0.0), rotation=90.0)

    d = geom.d
    ax.plot([h - d, h - d], [h, h + 0.095], color="black", linewidth=0.65)
    ax.plot([h, h], [h, h + 0.095], color="black", linewidth=0.65)
    add_tick_dim_h(ax, h - d, h, h + 0.075, f"D = {geom.d:.6f} H", (h - 0.5 * d, h + 0.120), fontsize=10.8)
    ax.plot([h, h + 0.095], [h - d, h - d], color="black", linewidth=0.65)
    ax.plot([h, h + 0.095], [h, h], color="black", linewidth=0.65)
    add_tick_dim_v(ax, h + 0.075, h - d, h, "D", (h + 0.120, h - 0.5 * d), fontsize=10.8)

    c_depth = geom.groove_depth
    q = geom.groove_half_opening
    centre_x = h + geom.groove_centre_offset_outside_face
    deepest_x = h - c_depth
    ax.plot([centre_x], [0.0], marker="+", color="black", markersize=7, mew=1.0)
    add_dim_arrow(ax, (h, 0.060), (deepest_x, 0.060), "C", (h - 0.5 * c_depth, 0.086), fontsize=10.8)
    add_dim_arrow(ax, (h + 0.060, -q), (h + 0.060, q), "2q", (h + 0.105, 0.0), rotation=90.0, fontsize=10.8)
    ax.plot([h, h + 0.070], [-q, -q], color="black", linewidth=0.65)
    ax.plot([h, h + 0.070], [q, q], color="black", linewidth=0.65)
    ax.plot([centre_x, deepest_x], [0.0, 0.0], color="0.35", linewidth=0.75)
    add_dim_arrow(ax, (centre_x, 0.0), (deepest_x, 0.0), f"R = {geom.r:.6f} H", ((centre_x + deepest_x) / 2.0, -0.034), fontsize=10.8)

    if top:
        note = "Top plane\nB is measured on the actual top face. The face is flat; the plan outline contains only the vertical lateral corner chamfers and four single-arc grooves."
    else:
        note = "Bottom plane\nA is measured on the bottom face. The same D and r definitions are used; only the bounding width changes from B to A."
    add_note(ax, -0.84, 0.95, note, width=40)
    add_note(
        ax,
        0.30,
        -0.44,
        "Groove values\n"
        f"C/H = {geom.c:.6f}\n"
        f"q/H = {geom.groove_half_opening:.6f}\n"
        f"r = R/H = {geom.r:.6f}\n"
        f"e = E/H = {geom.groove_centre_offset_outside_face:.6f}",
        width=38,
    )

    ax.set_xlim(-0.86, 0.98)
    ax.set_ylim(-0.79, 0.99)
    add_page_footer(fig, 2 if top else 4, 5)
    pdf.savefig(fig)
    plt.close(fig)


def pdf_groove_detail(pdf: PdfPages, geom: AntiferGeometry) -> None:
    """Write the enlarged groove-construction page."""
    fig, ax = make_page("Carvalho Antifer groove construction - single circular arc")
    fig.subplots_adjust(left=0.055, right=0.965, bottom=0.080, top=0.88)

    c_depth = geom.groove_depth
    q = geom.groove_half_opening
    offset = geom.groove_centre_offset_outside_face

    ax.set_aspect("equal", adjustable="box")
    ax.axis("off")
    ax.plot([0.0, 0.0], [-0.145, 0.145], color="black", linewidth=2.0)
    ax.plot([-0.150, 0.115], [0.0, 0.0], color="0.75", linewidth=0.7, linestyle="-.")

    display_arc = [(-x, y) for x, y in east_side_local_points(geom, n=ARC_POINTS)]
    ax.plot([p[0] for p in display_arc], [p[1] for p in display_arc], color="black", linewidth=2.2)

    centre = (offset, 0.0)
    deepest = (-c_depth, 0.0)
    upper_opening = (0.0, q)
    lower_opening = (0.0, -q)

    ax.plot([centre[0]], [centre[1]], marker="+", color="black", markersize=8, mew=1.0)
    ax.plot([centre[0], deepest[0]], [0.0, 0.0], color="0.35", linewidth=0.9)
    ax.plot([centre[0], upper_opening[0]], [centre[1], upper_opening[1]], color="0.35", linewidth=0.9)
    ax.plot([centre[0], lower_opening[0]], [centre[1], lower_opening[1]], color="0.35", linewidth=0.9)

    add_dim_arrow(ax, (0.0, 0.060), (-c_depth, 0.060), "C", (-0.5 * c_depth, 0.082), fontsize=10.8)
    add_dim_arrow(ax, (0.062, -q), (0.062, q), "2q", (0.083, 0.0), rotation=90.0, fontsize=10.8)
    add_dim_arrow(ax, (0.0, -0.108), (offset, -0.108), "e", (0.5 * offset, -0.128), fontsize=10.8)
    add_dim_arrow(ax, centre, deepest, f"R = {geom.r:.6f} H", ((centre[0] + deepest[0]) / 2.0, -0.026), fontsize=10.8)

    ax.text(0.004, 0.136, "side face", fontsize=10.8, ha="left", va="bottom")
    add_note(
        ax,
        -0.145,
        -0.165,
        "Dimensionless groove definition\n"
        f"C/H = {geom.c:.6f}\n"
        f"r = R/H = {geom.r:.6f}\n"
        f"e = E/H = {geom.groove_centre_offset_outside_face:.6f}\n"
        f"q/H = {geom.groove_half_opening:.6f}\n"
        f"2q/H = {geom.groove_opening:.6f}\n"
        "The groove is one continuous circular arc; no straight inner segment is used.",
        fontsize=10.8,
        width=55,
    )

    ax.set_xlim(-0.180, 0.135)
    ax.set_ylim(-0.230, 0.165)
    add_page_footer(fig, 3, 5)
    pdf.savefig(fig)
    plt.close(fig)

def pdf_formula_page(pdf: PdfPages, geom: AntiferGeometry) -> None:
    """Write the algebraic volume-balance page."""
    fig = plt.figure(figsize=PDF_SIZE_A4_LANDSCAPE)
    fig.subplots_adjust(left=0.055, right=0.965, bottom=0.075, top=0.88)
    ax = fig.add_subplot(111)
    ax.axis("off")
    fig.suptitle("Carvalho Antifer geometry - algebraic volume definition", fontsize=18, weight="bold")

    box = {"boxstyle": "round,pad=0.35", "fc": "white", "ec": "0.55", "lw": 0.8}
    mono = "DejaVu Sans Mono"

    left = [
        "1. Variables",
        f"a = A/H = {geom.a:.6f}",
        f"b = B/H = {geom.b:.6f}",
        f"c = C/H = {geom.c:.6f}",
        f"d = D/H = {geom.d:.6f}",
        f"r = R/H = {geom.r:.6f}",
        f"Kv = {geom.carvalho_kv:.6f}",
        "",
        "2. Required groove area",
        "Ag = [(a^2 + ab + b^2)/3 - 2d^2 - Kv] / 4",
        f"Ag = {geom.target_one_groove_area:.6f}",
        "",
        "3. Solved single-arc geometry",
        "Ag = r**2 acos(e/r) - e sqrt(r**2 - e**2)",
        f"e = E/H = {geom.groove_centre_offset_outside_face:.6f}",
        f"C/H = r - e = {geom.c:.6f}",
        f"q/H = sqrt(r^2 - e^2) = {geom.groove_half_opening:.6f}",
    ]

    right = [
        "4. Circular groove control",
        f"C/H = {geom.c:.6f}",
        f"r = R/H = {geom.r:.6f}",
        f"e = E/H = r - C = {geom.groove_centre_offset_outside_face:.6f}",
        f"q/H = {geom.groove_half_opening:.6f}",
        f"2q/H = {geom.groove_opening:.6f}",
        "",
        "5. Solid volume",
        "V/H^3 = (a^2 + a b + b^2)/3",
        "        - 2 d^2",
        "        - 4 Ag",
        f"gross frustum = {geom.gross_square_frustum_coefficient:.6f}",
        f"corner chamfers = {geom.removed_corner_volume_coefficient:.6f}",
        f"four grooves = {geom.removed_groove_volume_coefficient:.6f}",
        f"V/H^3 = {geom.exact_volume_coefficient:.6f}",
        f"residual to Carvalho Kv = {geom.residual_to_carvalho:+.6e}",
    ]

    ax.text(0.035, 0.91, "\n".join(left), ha="left", va="top", fontsize=12.0, family=mono, bbox=box)
    ax.text(0.515, 0.91, "\n".join(right), ha="left", va="top", fontsize=12.0, family=mono, bbox=box)

    summary = [
        "6. Interpretation",
        "The first term is the square-frustum volume between A and B.",
        "The second term removes the four lateral corner chamfers.",
        "The final term removes the four identical single-arc grooves.",
        "The auxiliary straight inner groove segment is not used.",
        "The circular-segment area is determined by the adopted Carvalho coefficient Kv = 1.",
    ]
    ax.text(0.035, 0.20, "\n".join(summary), ha="left", va="top", fontsize=12.2, bbox=box)

    add_page_footer(fig, 5, 5)
    pdf.savefig(fig)
    plt.close(fig)


def set_pdf_continuous_scrolling(path: Path) -> None:
    """Request continuous single-column opening layout in PDF viewers.

    The PDF standard represents this preference through the document catalog
    PageLayout entry. Many viewers interpret /OneColumn as continuous vertical
    scrolling. Viewers may still allow users to override the preference.
    """
    try:
        from pypdf import PdfReader, PdfWriter
        from pypdf.generic import NameObject
    except ImportError:
        return

    try:
        reader = PdfReader(str(path))
        writer = PdfWriter()
        for page in reader.pages:
            writer.add_page(page)
        if reader.metadata:
            writer.add_metadata(dict(reader.metadata))
        writer._root_object.update({NameObject("/PageLayout"): NameObject("/OneColumn")})
        writer._root_object.update({NameObject("/PageMode"): NameObject("/UseNone")})
        with path.open("wb") as handle:
            writer.write(handle)
    except Exception:
        return


def write_pdf(path: Path, geom: AntiferGeometry) -> None:
    """Generate all PDF pages and then apply optional viewer preferences."""
    with PdfPages(path) as pdf:
        pdf_front_view(pdf, geom)
        pdf_plan_view(pdf, geom, top=True)
        pdf_groove_detail(pdf, geom)
        pdf_plan_view(pdf, geom, top=False)
        pdf_formula_page(pdf, geom)
    set_pdf_continuous_scrolling(path)


# =============================================================================
# DXF WRITER
# =============================================================================


@dataclass(frozen=True)
class Extents:
    """Model-space drawing extents used to initialise the DXF viewport."""

    xmin: float
    ymin: float
    xmax: float
    ymax: float


def dxf_fmt(value: float) -> str:
    """Format a DXF coordinate with stable decimal precision."""
    if abs(value) < 1.0e-12:
        value = 0.0
    return f"{value:.12f}".rstrip("0").rstrip(".")


def dxf_safe_text(text: str) -> str:
    """Return conservative ASCII text for R12 DXF TEXT entities.

    Some CAD text engines handle caret exponents, Unicode superscripts or
    mathematical symbols inconsistently. The formulas are therefore written
    with ASCII power notation so they remain legible in ZWCAD/AutoCAD-type
    viewers using SHX or limited legacy fonts.
    """
    replacements = {
        "²": "**2",
        "³": "**3",
        "⁻": "-",
        "⁺": "+",
        "×": "x",
        "−": "-",
        "–": "-",
        "—": "-",
        "α": "alpha",
        "θ": "theta",
        "Δ": "Delta",
    }
    for original, replacement in replacements.items():
        text = text.replace(original, replacement)
    text = text.replace("^2", "**2").replace("^3", "**3")
    text = text.replace("\n", " / ")
    return text.encode("ascii", "replace").decode("ascii")


class DXF:
    """Minimal ASCII DXF R12 writer for simple 2D engineering drawings.

    The class writes only the entities needed by this script. Keeping the writer
    local and explicit avoids a dependency on a CAD package while preserving a
    predictable entity order for ZWCAD/AutoCAD-compatible viewers.
    """

    def __init__(self) -> None:
        self.entities: list[str] = []

    def add_line(self, x1: float, y1: float, x2: float, y2: float, layer: str = "GEOMETRY", ltype: str | None = None) -> None:
        entity = ["0", "LINE", "8", layer]
        if ltype:
            entity += ["6", ltype]
        entity += ["10", dxf_fmt(x1), "20", dxf_fmt(y1), "30", "0", "11", dxf_fmt(x2), "21", dxf_fmt(y2), "31", "0"]
        self.entities.append("\n".join(entity))

    def add_polyline(self, points: Polyline2D, closed: bool = False, layer: str = "GEOMETRY", ltype: str | None = None) -> None:
        entity = ["0", "POLYLINE", "8", layer]
        if ltype:
            entity += ["6", ltype]
        entity += ["66", "1", "70", "1" if closed else "0"]
        self.entities.append("\n".join(entity))
        for x, y in points:
            self.entities.append("\n".join(["0", "VERTEX", "8", layer, "10", dxf_fmt(x), "20", dxf_fmt(y), "30", "0"]))
        self.entities.append("\n".join(["0", "SEQEND", "8", layer]))

    def add_solid(self, points: Polyline2D, layer: str = "DIM") -> None:
        pts = points[:]
        if len(pts) == 3:
            pts.append(pts[-1])
        entity = ["0", "SOLID", "8", layer]
        for idx, (x, y) in enumerate(pts):
            entity += [str(10 + idx), dxf_fmt(x), str(20 + idx), dxf_fmt(y), str(30 + idx), "0"]
        self.entities.append("\n".join(entity))

    def add_text(self, x: float, y: float, text: str, height: float = 0.035, layer: str = "TEXT", rotation: float = 0.0, align: str = "LEFT") -> None:
        text = dxf_safe_text(text)
        entity = ["0", "TEXT", "8", layer, "10", dxf_fmt(x), "20", dxf_fmt(y), "30", "0", "40", dxf_fmt(height), "1", text, "50", dxf_fmt(rotation)]
        if align.upper() == "CENTER":
            entity += ["72", "1", "11", dxf_fmt(x), "21", dxf_fmt(y), "31", "0"]
        elif align.upper() == "MIDDLE":
            entity += ["72", "1", "73", "2", "11", dxf_fmt(x), "21", dxf_fmt(y), "31", "0"]
        elif align.upper() == "RIGHT":
            entity += ["72", "2", "11", dxf_fmt(x), "21", dxf_fmt(y), "31", "0"]
        self.entities.append("\n".join(entity))

    def write(self, path: Path, extents: Extents) -> None:
        margin = 0.25
        xmin = extents.xmin - margin
        ymin = extents.ymin - margin
        xmax = extents.xmax + margin
        ymax = extents.ymax + margin
        view_width = xmax - xmin
        view_height = ymax - ymin
        aspect = max(1.0, view_width / max(view_height, 1.0e-9))
        active_height = max(view_height, view_width / aspect)
        view_cx = 0.5 * (xmin + xmax)
        view_cy = 0.5 * (ymin + ymax)
        header = [
            "0", "SECTION", "2", "HEADER",
            "9", "$ACADVER", "1", "AC1009",
            "9", "$EXTMIN", "10", dxf_fmt(xmin), "20", dxf_fmt(ymin), "30", "0",
            "9", "$EXTMAX", "10", dxf_fmt(xmax), "20", dxf_fmt(ymax), "30", "0",
            "9", "$LIMMIN", "10", dxf_fmt(xmin), "20", dxf_fmt(ymin),
            "9", "$LIMMAX", "10", dxf_fmt(xmax), "20", dxf_fmt(ymax),
            "9", "$VIEWCTR", "10", dxf_fmt(view_cx), "20", dxf_fmt(view_cy),
            "9", "$VIEWSIZE", "40", dxf_fmt(active_height),
            "9", "$TILEMODE", "70", "1",
            "9", "$CVPORT", "70", "1",
            "9", "$INSBASE", "10", "0", "20", "0", "30", "0",
            "0", "ENDSEC",
        ]
        tables = [
            "0", "SECTION", "2", "TABLES",
            "0", "TABLE", "2", "LTYPE", "70", "3",
            "0", "LTYPE", "2", "CONTINUOUS", "70", "0", "3", "Solid", "72", "65", "73", "0", "40", "0",
            "0", "LTYPE", "2", "DASHED", "70", "0", "3", "Dashed", "72", "65", "73", "2", "40", "0.12", "49", "0.075", "49", "-0.045",
            "0", "LTYPE", "2", "CENTER", "70", "0", "3", "Center", "72", "65", "73", "4", "40", "0.16", "49", "0.09", "49", "-0.025", "49", "0.015", "49", "-0.025",
            "0", "ENDTAB",
            "0", "TABLE", "2", "LAYER", "70", "8",
            "0", "LAYER", "2", "GEOMETRY", "70", "0", "62", "7", "6", "CONTINUOUS",
            "0", "LAYER", "2", "DIM", "70", "0", "62", "2", "6", "CONTINUOUS",
            "0", "LAYER", "2", "TEXT", "70", "0", "62", "3", "6", "CONTINUOUS",
            "0", "LAYER", "2", "CENTER", "70", "0", "62", "1", "6", "CENTER",
            "0", "LAYER", "2", "BORDER", "70", "0", "62", "8", "6", "CONTINUOUS",
            "0", "LAYER", "2", "NOTES", "70", "0", "62", "4", "6", "CONTINUOUS",
            "0", "LAYER", "2", "DETAIL", "70", "0", "62", "5", "6", "CONTINUOUS",
            "0", "LAYER", "2", "REFERENCE", "70", "0", "62", "8", "6", "DASHED",
            "0", "ENDTAB",
            "0", "TABLE", "2", "VPORT", "70", "1",
            "0", "VPORT", "2", "*ACTIVE", "70", "0",
            "10", "0", "20", "0",
            "11", "1", "21", "1",
            "12", dxf_fmt(view_cx), "22", dxf_fmt(view_cy),
            "13", "0", "23", "0",
            "14", "0.1", "24", "0.1",
            "15", "0.1", "25", "0.1",
            "16", "0", "26", "0", "36", "1",
            "17", "0", "27", "0", "37", "0",
            "40", dxf_fmt(active_height), "41", dxf_fmt(aspect),
            "42", "50", "43", "0", "44", "0",
            "50", "0", "51", "0",
            "71", "0", "72", "100", "73", "1", "74", "3",
            "75", "0", "76", "0", "77", "0", "78", "0",
            "0", "ENDTAB", "0", "ENDSEC",
        ]
        content = header + tables + ["0", "SECTION", "2", "ENTITIES"]
        for entity in self.entities:
            content.extend(entity.split("\n"))
        content += ["0", "ENDSEC", "0", "EOF"]
        path.write_text("\n".join(content) + "\n", encoding="ascii")


# DXF graphic sizing. The four principal views share a common centre axis and
# equal horizontal centre-to-centre spacing.
DXF_ARROW = 0.025
DXF_TEXT = 0.044
DXF_SMALL = 0.034
DXF_FRONT_SCALE = 1.18
DXF_PLAN_SCALE = 1.18
DXF_GROOVE_DETAIL_SCALE = 3.35
DXF_COMMON_AXIS_Y = 0.10
DXF_PANEL_STEP = 2.35


def dxf_arrowhead(dxf: DXF, x: float, y: float, angle: float, size: float = DXF_ARROW) -> None:
    """Draw a filled triangular arrowhead in model space."""
    p1 = (x, y)
    p2 = (x + size * math.cos(angle + math.radians(150.0)), y + size * math.sin(angle + math.radians(150.0)))
    p3 = (x + size * math.cos(angle - math.radians(150.0)), y + size * math.sin(angle - math.radians(150.0)))
    dxf.add_solid([p1, p2, p3], layer="DIM")


def dxf_dim_h(dxf: DXF, x1: float, x2: float, y: float, label: str) -> None:
    dxf.add_line(x1, y, x2, y, layer="DIM")
    dxf_arrowhead(dxf, x1, y, 0.0)
    dxf_arrowhead(dxf, x2, y, math.pi)
    dxf.add_text(0.5 * (x1 + x2), y + 0.03, label, DXF_SMALL, align="CENTER")


def dxf_dim_v(dxf: DXF, x: float, y1: float, y2: float, label: str) -> None:
    dxf.add_line(x, y1, x, y2, layer="DIM")
    dxf_arrowhead(dxf, x, y1, math.pi / 2.0)
    dxf_arrowhead(dxf, x, y2, -math.pi / 2.0)
    dxf.add_text(x + 0.03, 0.5 * (y1 + y2), label, DXF_SMALL, rotation=90.0, align="CENTER")


def dxf_tick_dim_h(dxf: DXF, x1: float, x2: float, y: float, label: str) -> None:
    dxf.add_line(x1, y, x2, y, layer="DIM")
    tick = 0.012
    dxf.add_line(x1, y - tick, x1, y + tick, layer="DIM")
    dxf.add_line(x2, y - tick, x2, y + tick, layer="DIM")
    dxf.add_text(0.5 * (x1 + x2), y + 0.035, label, DXF_SMALL, align="CENTER")


def translate(points: Polyline2D, ox: float, oy: float) -> Polyline2D:
    """Translate a polyline by an XY offset."""
    return [(ox + x, oy + y) for x, y in points]


def translate_scaled(points: Polyline2D, ox: float, oy: float, scale: float) -> Polyline2D:
    """Scale a polyline about the local origin and translate it to model space."""
    return [(ox + scale * x, oy + scale * y) for x, y in points]


def dxf_write_wrapped(dxf: DXF, x: float, y: float, lines: list[str], height: float = DXF_SMALL, step: float = 0.060) -> None:
    for i, line in enumerate(lines):
        dxf.add_text(x, y - step * i, line, height=height, layer="NOTES")


def dxf_draw_front(dxf: DXF, ox: float, oy: float, geom: AntiferGeometry) -> None:
    scale = DXF_FRONT_SCALE
    a2 = 0.5 * geom.a * scale
    b2 = 0.5 * geom.b * scale
    d = geom.d * scale
    z0 = oy - 0.5 * scale
    z1 = oy + 0.5 * scale
    outline = [(ox - a2, z0), (ox + a2, z0), (ox + b2, z1), (ox - b2, z1), (ox - a2, z0)]
    dxf.add_polyline(outline, closed=False, layer="GEOMETRY")
    dxf.add_line(ox - (a2 - d), z0, ox - (b2 - d), z1, layer="REFERENCE", ltype="DASHED")
    dxf.add_line(ox + (a2 - d), z0, ox + (b2 - d), z1, layer="REFERENCE", ltype="DASHED")
    dxf_dim_h(dxf, ox - a2, ox + a2, z0 - 0.16 * scale, f"A/H = {geom.a:.6f}")
    dxf_dim_h(dxf, ox - b2, ox + b2, z1 + 0.17 * scale, f"B/H = {geom.b:.6f}")
    dxf_dim_v(dxf, ox + a2 + 0.24 * scale, z0, z1, "H")
    dxf.add_text(ox, z1 + 0.32 * scale, "FRONT VIEW", DXF_TEXT, align="CENTER")
    dxf.add_text(ox - 0.66 * scale, oy - 0.04 * scale, "no top bevel", DXF_SMALL, layer="NOTES")


def dxf_draw_plan(dxf: DXF, ox: float, oy: float, geom: AntiferGeometry, width: float, label: str) -> None:
    scale = DXF_PLAN_SCALE
    for segment in section_segments(width, geom):
        dxf.add_polyline(translate_scaled(segment, ox, oy, scale), closed=False, layer="GEOMETRY")
    h = 0.5 * width * scale
    d = geom.d * scale
    q = geom.groove_half_opening * scale
    c_depth = geom.groove_depth * scale
    centre_offset = geom.groove_centre_offset_outside_face * scale
    dxf.add_line(ox - h - 0.06 * scale, oy, ox + h + 0.06 * scale, oy, layer="CENTER", ltype="CENTER")
    dxf.add_line(ox, oy - h - 0.06 * scale, ox, oy + h + 0.06 * scale, layer="CENTER", ltype="CENTER")
    dxf_dim_h(dxf, ox - h, ox + h, oy - h - 0.15 * scale, label)
    dxf_dim_v(dxf, ox + h + 0.15 * scale, oy - h, oy + h, label)
    dxf_tick_dim_h(dxf, ox + h - d, ox + h, oy + h + 0.08 * scale, f"D/H = {geom.d:.6f}")
    dxf_dim_v(dxf, ox + h + 0.28 * scale, oy + h - d, oy + h, "D")

    deepest_x = ox + h - c_depth
    centre_x = ox + h + centre_offset
    dxf_dim_h(dxf, ox + h, deepest_x, oy + 0.085 * scale, "C/H")
    dxf_dim_v(dxf, ox + h + 0.08 * scale, oy - q, oy + q, "2q")
    dxf.add_line(centre_x, oy, deepest_x, oy, layer="DIM")
    dxf.add_text(0.5 * (centre_x + deepest_x), oy - 0.045 * scale, f"R/H = {geom.r:.6f}", DXF_SMALL, layer="TEXT", align="CENTER")
    dxf.add_text(
        ox - h + 0.02 * scale,
        oy - h + 0.06 * scale,
        f"C/H = {geom.c:.6f}",
        DXF_SMALL,
        layer="NOTES",
    )
    dxf.add_text(
        ox - h + 0.02 * scale,
        oy - h + 0.12 * scale,
        f"q/H = {geom.groove_half_opening:.6f}",
        DXF_SMALL,
        layer="NOTES",
    )
    dxf.add_text(ox, oy + h + 0.22 * scale, "TOP VIEW" if label.startswith("B") else "BOTTOM VIEW", DXF_TEXT, align="CENTER")


def dxf_draw_groove_detail(dxf: DXF, ox: float, oy: float, geom: AntiferGeometry) -> None:
    scale = DXF_GROOVE_DETAIL_SCALE
    local = [(-x * scale, y * scale) for x, y in east_side_local_points(geom, n=ARC_POINTS)]
    dxf.add_polyline(translate(local, ox, oy), closed=False, layer="DETAIL")
    c_depth = geom.groove_depth * scale
    q = geom.groove_half_opening * scale
    offset = geom.groove_centre_offset_outside_face * scale
    dxf.add_line(ox, oy - q, ox, oy + q, layer="GEOMETRY")
    dxf_dim_h(dxf, ox, ox - c_depth, oy + 0.055 * scale, "C/H")
    dxf_dim_v(dxf, ox + 0.075 * scale, oy - q, oy + q, "2q")
    dxf_dim_h(dxf, ox, ox + offset, oy - 0.108 * scale, "e")
    centre_x = ox + offset
    deepest_x = ox - c_depth
    dxf.add_line(centre_x, oy, deepest_x, oy, layer="DIM")
    dxf.add_text(0.5 * (centre_x + deepest_x), oy - 0.045 * scale, f"R/H = {geom.r:.6f}", DXF_SMALL, layer="TEXT", align="CENTER")
    dxf.add_text(ox, oy + 0.19 * scale, "GROOVE DETAIL", DXF_TEXT, align="CENTER")
    dxf.add_text(ox - 0.18 * scale, oy - 0.18 * scale, f"C/H={geom.c:.6f}", DXF_SMALL, layer="NOTES")


def write_dxf(path: Path, geom: AntiferGeometry) -> None:
    """Generate the complete dimensioned DXF sheet."""
    dxf = DXF()
    xmin, ymin, xmax, ymax = -1.35, -1.88, 8.65, 1.72
    dxf.add_line(xmin, ymin, xmax, ymin, layer="BORDER")
    dxf.add_line(xmax, ymin, xmax, ymax, layer="BORDER")
    dxf.add_line(xmax, ymax, xmin, ymax, layer="BORDER")
    dxf.add_line(xmin, ymax, xmin, ymin, layer="BORDER")
    dxf.add_text(0.5 * (xmin + xmax), ymax - 0.12, "CARVALHO ANTIFER GEOMETRY - NON-DIMENSIONAL VIEWS", height=0.052, layer="TEXT", align="CENTER")

    # Principal figure centres: equal spacing on one common horizontal axis.
    axis_y = DXF_COMMON_AXIS_Y
    first_panel_x = 0.00
    top_plan_x = first_panel_x + DXF_PANEL_STEP
    groove_detail_x = first_panel_x + 2.0 * DXF_PANEL_STEP
    bottom_plan_x = first_panel_x + 3.0 * DXF_PANEL_STEP
    dxf_draw_front(dxf, first_panel_x, axis_y, geom)
    dxf_draw_plan(dxf, top_plan_x, axis_y, geom, geom.b, f"B/H = {geom.b:.6f}")
    dxf_draw_groove_detail(dxf, groove_detail_x, axis_y, geom)
    dxf_draw_plan(dxf, bottom_plan_x, axis_y, geom, geom.a, f"A/H = {geom.a:.6f}")

    note_lines = [
        "Exact algebraic definition:",
        f"a=A/H={geom.a:.6f}   b=B/H={geom.b:.6f}   c=C/H={geom.c:.6f}",
        f"d=D/H={geom.d:.6f}   r=R/H={geom.r:.6f}   Kv={geom.carvalho_kv:.6f}",
        f"(A-B)/2H={geom.side_batter_per_side:.6f}",
        f"e=E/H={geom.groove_centre_offset_outside_face:.6f}",
        f"q/H={geom.groove_half_opening:.6f}   2q/H={geom.groove_opening:.6f}",
        "Ag = r**2 acos(e/r) - e sqrt(r**2 - e**2)",
        "V/H**3 = (a**2 + a*b + b**2)/3 - 2*d**2 - 4*Ag",
        f"Ag={geom.one_groove_area:.6f}   4Ag={geom.removed_groove_volume_coefficient:.6f}",
        f"V/H**3={geom.exact_volume_coefficient:.6f}",
        f"residual={geom.residual_to_carvalho:+.6e}",
    ]
    dxf_write_wrapped(dxf, -1.10, -1.05, note_lines, height=DXF_SMALL, step=0.070)
    dxf.write(path, Extents(xmin, ymin, xmax, ymax))


# =============================================================================
# MAIN PROGRAM
# =============================================================================


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments for output folder and filenames."""
    parser = argparse.ArgumentParser(description="Generate Carvalho Antifer geometry PDF and DXF.")
    parser.add_argument("--out-dir", default=".", help="Output directory. Default: current directory.")
    parser.add_argument("--pdf", default="antifer_carvalho_geometry.pdf", help="PDF output filename.")
    parser.add_argument("--dxf", default="antifer_carvalho_geometry.dxf", help="DXF output filename.")
    return parser.parse_args()


def main() -> None:
    """Command-line entry point."""
    args = parse_args()
    out_dir = Path(args.out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    pdf_path = out_dir / args.pdf
    dxf_path = out_dir / args.dxf
    geom = AntiferGeometry()
    write_pdf(pdf_path, geom)
    write_dxf(dxf_path, geom)
    print(f"PDF written: {pdf_path}")
    print(f"DXF written: {dxf_path}")
    print(f"V/H^3: {geom.exact_volume_coefficient:.6f}")
    print(f"Residual to CARVALHO_KV: {geom.residual_to_carvalho:+.6e}")
    print(f"C/H: {geom.c:.6f}")
    print(f"r = R/H: {geom.r:.6f}")
    print(f"e = E/H: {geom.groove_centre_offset_outside_face:.6f}")
    print(f"q/H: {geom.groove_half_opening:.6f}")


if __name__ == "__main__":
    main()
